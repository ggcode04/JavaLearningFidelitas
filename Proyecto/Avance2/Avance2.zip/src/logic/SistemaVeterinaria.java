/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logic;
import model.Cliente;
import model.Mascota;
import model.Servicio;

/**
 *
 * @author gabri
 */

public class SistemaVeterinaria {

    private static final int MAX_CLIENTES = 100;
    private static final int MAX_MASCOTAS = 100;
    private static final int CANTIDAD_SERVICIOS = 4;

    private final Cliente[] clientes;
    private int totalClientes;

    private final Mascota[] mascotas;
    private int totalMascotas;

    private final Servicio[] servicios;

    public SistemaVeterinaria() {
        clientes = new Cliente[MAX_CLIENTES];
        mascotas = new Mascota[MAX_MASCOTAS];
        servicios = new Servicio[CANTIDAD_SERVICIOS];

        totalClientes = 0;
        totalMascotas = 0;

        inicializarServicios();
    }

    private void inicializarServicios() {
        servicios[0] =
                new Servicio("S01", "Consulta general", 15000);
        servicios[1] =
                new Servicio("S02", "Vacunacion", 12000);
        servicios[2] =
                new Servicio("S03", "Desparasitacion", 10000);
        servicios[3] =
                new Servicio("S04", "Emergencia", 30000);
    }

    public String registrarCliente(String nombreCompleto,
                                   String identificacion,
                                   String telefono,
                                   String correo) {

        if (nombreCompleto == null || nombreCompleto.trim().isEmpty()) {
            return "Error: El nombre del cliente no puede estar vacio.";
        }

        if (identificacion == null || identificacion.trim().isEmpty()) {
            return "Error: La identificacion no puede estar vacia.";
        }

        if (buscarClientePorIdentificacion(identificacion) != null) {
            return "Error: Ya existe un cliente con esa identificacion.";
        }

        if (totalClientes >= clientes.length) {
            return "Error: Se alcanzo el limite maximo de clientes.";
        }

        clientes[totalClientes] = new Cliente(
                nombreCompleto.trim(),
                identificacion.trim(),
                telefono == null ? "" : telefono.trim(),
                correo == null ? "" : correo.trim()
        );

        totalClientes++;
        return "Cliente registrado correctamente.";
    }

    public Cliente buscarClientePorIdentificacion(String identificacion) {
        if (identificacion == null) {
            return null;
        }

        for (int i = 0; i < totalClientes; i++) {
            if (clientes[i].getIdentificacion()
                    .equalsIgnoreCase(identificacion.trim())) {
                return clientes[i];
            }
        }

        return null;
    }

    public String registrarMascota(String nombre,
                                   String especie,
                                   String raza,
                                   int edad,
                                   double peso,
                                   String identificacionDueno) {

        if (nombre == null || nombre.trim().isEmpty()) {
            return "Error: El nombre de la mascota no puede estar vacio.";
        }

        if (especie == null || especie.trim().isEmpty()) {
            return "Error: La especie no puede estar vacia.";
        }

        if (edad < 0) {
            return "Error: La edad no puede ser negativa.";
        }

        if (peso <= 0) {
            return "Error: El peso debe ser mayor que cero.";
        }

        if (buscarClientePorIdentificacion(identificacionDueno) == null) {
            return "Error: El dueño debe estar registrado previamente.";
        }

        if (totalMascotas >= mascotas.length) {
            return "Error: Se alcanzo el limite maximo de mascotas.";
        }

        mascotas[totalMascotas] = new Mascota(
                nombre.trim(),
                especie.trim(),
                raza == null ? "" : raza.trim(),
                edad,
                peso,
                identificacionDueno.trim()
        );

        totalMascotas++;
        return "Mascota registrada correctamente.";
    }

    public Cliente[] getClientes() {
        return clientes;
    }

    public int getTotalClientes() {
        return totalClientes;
    }

    public Mascota[] getMascotas() {
        return mascotas;
    }

    public int getTotalMascotas() {
        return totalMascotas;
    }

    public Servicio[] getServicios() {
        return servicios;
    }
}
