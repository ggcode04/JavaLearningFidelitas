/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author gabri
 */
public class Mascota {

    private String nombre;
    private String especie;
    private String raza;
    private int edad;
    private double peso;
    private String identificacionDueno;

    public Mascota(String nombre, String especie, String raza,
                   int edad, double peso, String identificacionDueno) {
        this.nombre = nombre;
        this.especie = especie;
        this.raza = raza;
        this.edad = edad;
        this.peso = peso;
        this.identificacionDueno = identificacionDueno;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String getIdentificacionDueno() {
        return identificacionDueno;
    }

    public void setIdentificacionDueno(String identificacionDueno) {
        this.identificacionDueno = identificacionDueno;
    }

    public String mostrarInformacionMascota() {
        return "Nombre: " + nombre
                + "\nEspecie: " + especie
                + "\nRaza: " + raza
                + "\nEdad: " + edad + " años"
                + "\nPeso: " + peso + " kg"
                + "\nIdentificacion del dueño: " + identificacionDueno;
    }

    @Override
    public String toString() {
        return mostrarInformacionMascota();
    }
}
