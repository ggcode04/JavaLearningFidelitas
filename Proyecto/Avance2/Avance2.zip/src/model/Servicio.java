/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author gabri
 */
public class Servicio {

    public static final double PORCENTAJE_IVA = 0.13;

    private String codigo;
    private String nombreServicio;
    private double precioBase;

    public Servicio(String codigo, String nombreServicio, double precioBase) {
        this.codigo = codigo;
        this.nombreServicio = nombreServicio;
        this.precioBase = precioBase;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombreServicio() {
        return nombreServicio;
    }

    public void setNombreServicio(String nombreServicio) {
        this.nombreServicio = nombreServicio;
    }

    public double getPrecioBase() {
        return precioBase;
    }

    public void setPrecioBase(double precioBase) {
        this.precioBase = precioBase;
    }

    public double calcularSubtotal() {
        return precioBase;
    }

    public double calcularIVA() {
        return calcularSubtotal() * PORCENTAJE_IVA;
    }

    public double calcularPrecioServicio() {
        return calcularSubtotal() + calcularIVA();
    }

    public String mostrarServicio() {
        return "Codigo: " + codigo
                + "\nServicio: " + nombreServicio
                + "\nSubtotal: " + String.format("%.2f", calcularSubtotal())
                + "\nIVA: " + String.format("%.2f", calcularIVA())
                + "\nTotal: " + String.format("%.2f", calcularPrecioServicio());
    }

    @Override
    public String toString() {
        return mostrarServicio();
    }
}
