/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;
import java.util.Scanner;
import logic.SistemaVeterinaria;
import model.Cliente;
import model.Mascota;
import model.Servicio;

/**
 *
 * @author gabri
 */
public class Main {

    private static final Scanner ENTRADA = new Scanner(System.in);
    private static final SistemaVeterinaria SISTEMA =
            new SistemaVeterinaria();

    public static void main(String[] args) {
        int opcion;

        do {
            mostrarMenuPrincipal();
            opcion = leerEntero("Seleccione una opcion: ");

            switch (opcion) {
                case 1:
                    registrarCliente();
                    break;
                case 2:
                    listarClientes();
                    break;
                case 3:
                    registrarMascota();
                    break;
                case 4:
                    listarMascotas();
                    break;
                case 5:
                    mostrarServicios();
                    break;
                case 6:
                    System.out.println(
                            "\nGracias por utilizar Patitas Sanas."
                    );
                    break;
                default:
                    System.out.println(
                            "\nError: Seleccione una opcion valida."
                    );
            }

        } while (opcion != 6);

        ENTRADA.close();
    }

    private static void mostrarMenuPrincipal() {
        System.out.println("\n======================================");
        System.out.println(" CLINICA VETERINARIA PATITAS SANAS");
        System.out.println("======================================");
        System.out.println("1. Registrar cliente");
        System.out.println("2. Listar clientes");
        System.out.println("3. Registrar mascota");
        System.out.println("4. Listar mascotas");
        System.out.println("5. Mostrar servicios");
        System.out.println("6. Salir");
        System.out.println("======================================");
    }

    private static void registrarCliente() {
        System.out.println("\n--- REGISTRO DE CLIENTE ---");

        System.out.print("Nombre completo: ");
        String nombre = ENTRADA.nextLine();

        System.out.print("Identificacion: ");
        String identificacion = ENTRADA.nextLine();

        System.out.print("Telefono: ");
        String telefono = ENTRADA.nextLine();

        System.out.print("Correo electronico: ");
        String correo = ENTRADA.nextLine();

        String resultado = SISTEMA.registrarCliente(
                nombre,
                identificacion,
                telefono,
                correo
        );

        System.out.println("\n" + resultado);
    }

    private static void listarClientes() {
        System.out.println("\n--- CLIENTES REGISTRADOS ---");

        if (SISTEMA.getTotalClientes() == 0) {
            System.out.println("No hay clientes registrados.");
            return;
        }

        Cliente[] clientes = SISTEMA.getClientes();

        for (int i = 0; i < SISTEMA.getTotalClientes(); i++) {
            System.out.println("\nCliente #" + (i + 1));
            System.out.println(clientes[i].mostrarInformacionCliente());
        }
    }

    private static void registrarMascota() {
        System.out.println("\n--- REGISTRO DE MASCOTA ---");

        System.out.print("Nombre de la mascota: ");
        String nombre = ENTRADA.nextLine();

        System.out.print("Especie: ");
        String especie = ENTRADA.nextLine();

        System.out.print("Raza: ");
        String raza = ENTRADA.nextLine();

        int edad = leerEntero("Edad en años: ");
        double peso = leerDouble("Peso en kilogramos: ");

        System.out.print("Identificacion del dueño: ");
        String identificacionDueno = ENTRADA.nextLine();

        String resultado = SISTEMA.registrarMascota(
                nombre,
                especie,
                raza,
                edad,
                peso,
                identificacionDueno
        );

        System.out.println("\n" + resultado);
    }

    private static void listarMascotas() {
        System.out.println("\n--- MASCOTAS REGISTRADAS ---");

        if (SISTEMA.getTotalMascotas() == 0) {
            System.out.println("No hay mascotas registradas.");
            return;
        }

        Mascota[] mascotas = SISTEMA.getMascotas();

        for (int i = 0; i < SISTEMA.getTotalMascotas(); i++) {
            System.out.println("\nMascota #" + (i + 1));
            System.out.println(mascotas[i].mostrarInformacionMascota());
        }
    }

    private static void mostrarServicios() {
        System.out.println("\n--- SERVICIOS VETERINARIOS ---");

        for (Servicio servicio : SISTEMA.getServicios()) {
            System.out.println();
            System.out.println(servicio.mostrarServicio());
        }
    }

    private static int leerEntero(String mensaje) {
        while (true) {
            try {
                System.out.print(mensaje);
                int valor = Integer.parseInt(ENTRADA.nextLine());
                return valor;
            } catch (NumberFormatException ex) {
                System.out.println(
                        "Error: Debe ingresar un numero entero."
                );
            }
        }
    }

    private static double leerDouble(String mensaje) {
        while (true) {
            try {
                System.out.print(mensaje);
                String texto = ENTRADA.nextLine().replace(',', '.');
                return Double.parseDouble(texto);
            } catch (NumberFormatException ex) {
                System.out.println(
                        "Error: Debe ingresar un numero valido."
                );
            }
        }
    }
}

