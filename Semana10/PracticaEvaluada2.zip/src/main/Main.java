/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;
import model.Automovil;
import java.util.Scanner;

/**
 *
 * @author gabri
 */
public class Main {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.println("======== REGISTRO DE AUTOMÓVILES ========\n");

        // AUTOMÓVIL 1
        System.out.println("AUTOMOVIL 1");

        System.out.print("Marca: ");
        String marca = teclado.nextLine();

        System.out.print("Modelo: ");
        String modelo = teclado.nextLine();

        System.out.print("Año: ");
        int anio = teclado.nextInt();

        System.out.print("Cantidad de puertas: ");
        int puertas = teclado.nextInt();

        teclado.nextLine(); // Limpia el buffer

        System.out.print("Tipo de combustible: ");
        String combustible = teclado.nextLine();

        Automovil auto1 = new Automovil(
                marca,
                modelo,
                anio,
                puertas,
                combustible
        );

        System.out.println();

        // AUTOMÓVIL 2

        System.out.println("AUTOMOVIL 2");

        System.out.print("Marca: ");
        marca = teclado.nextLine();

        System.out.print("Modelo: ");
        modelo = teclado.nextLine();

        System.out.print("Año: ");
        anio = teclado.nextInt();

        System.out.print("Cantidad de puertas: ");
        puertas = teclado.nextInt();

        teclado.nextLine();

        System.out.print("Tipo de combustible: ");
        combustible = teclado.nextLine();

        Automovil auto2 = new Automovil(
                marca,
                modelo,
                anio,
                puertas,
                combustible
        );

        System.out.println("\n========================================");
        System.out.println("INFORMACION REGISTRADA");
        System.out.println("========================================\n");

        System.out.println("AUTOMOVIL 1");
        auto1.mostrarInformacion();

        System.out.println();

        System.out.println("AUTOMOVIL 2");
        auto2.mostrarInformacion();

        teclado.close();
    }
}