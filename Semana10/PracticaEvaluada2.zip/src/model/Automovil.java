/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author gabri
 */
public class Automovil extends Vehiculo {

    // Atributos propios de Automovil.
    private int cantidadPuertas;
    private String tipoCombustible;

    /**
     * Constructor de la clase Automovil.
     *
     * @param marca marca del automóvil
     * @param modelo modelo del automóvil
     * @param anio año del automóvil
     * @param cantidadPuertas cantidad de puertas
     * @param tipoCombustible tipo de combustible
     */
    public Automovil(
            String marca,
            String modelo,
            int anio,
            int cantidadPuertas,
            String tipoCombustible
    ) {
        /*
         * super() llama al constructor de la superclase Vehiculo.
         * Se utiliza para inicializar marca, modelo y anio.
         */
        super(marca, modelo, anio);

        setCantidadPuertas(cantidadPuertas);
        setTipoCombustible(tipoCombustible);
    }

    public int getCantidadPuertas() {
        return cantidadPuertas;
    }

    public void setCantidadPuertas(int cantidadPuertas) {
        if (cantidadPuertas < 2 || cantidadPuertas > 5) {
            System.out.println(
                    "La cantidad de puertas debe estar entre 2 y 5. "
                    + "Se asignaran 4 puertas."
            );

            this.cantidadPuertas = 4;
        } else {
            this.cantidadPuertas = cantidadPuertas;
        }
    }

    public String getTipoCombustible() {
        return tipoCombustible;
    }

    public void setTipoCombustible(String tipoCombustible) {
        if (
                tipoCombustible == null
                || tipoCombustible.trim().isEmpty()
        ) {
            System.out.println(
                    "El tipo de combustible no puede estar vacio. "
                    + "Se asignara: No especificado."
            );

            this.tipoCombustible = "No especificado";
        } else {
            this.tipoCombustible = tipoCombustible.trim();
        }
    }

    /**
     * Sobrescribe el método mostrarInformacion() de Vehiculo.
     */
    @Override
    public void mostrarInformacion() {
        /*
         * Llama al método de Vehiculo para mostrar
         * marca, modelo y año.
         */
        super.mostrarInformacion();

        // Muestra los atributos propios del automóvil.
        System.out.println(
                "Cantidad de puertas: " + cantidadPuertas
        );

        System.out.println(
                "Tipo de combustible: " + tipoCombustible
        );
    }
}
