/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.time.Year;

/**
 *
 * @author gabri
 */
public class Vehiculo {

    // Atributos privados para aplicar encapsulamiento.
    private String marca;
    private String modelo;
    private int anio;

    /**
     * Constructor de la clase Vehiculo.
     *
     * @param marca marca del vehículo
     * @param modelo modelo del vehículo
     * @param anio año del vehículo
     */
    public Vehiculo(String marca, String modelo, int anio) {
        setMarca(marca);
        setModelo(modelo);
        setAnio(anio);
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        if (marca == null || marca.trim().isEmpty()) {
            System.out.println(
                    "La marca no puede estar vacia. "
                    + "Se asignara: No especificada."
            );

            this.marca = "No especificada";
        } else {
            this.marca = marca.trim();
        }
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        if (modelo == null || modelo.trim().isEmpty()) {
            System.out.println(
                    "El modelo no puede estar vacio. "
                    + "Se asignara: No especificado."
            );

            this.modelo = "No especificado";
        } else {
            this.modelo = modelo.trim();
        }
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        int anioActual = Year.now().getValue();

        if (anio < 1900 || anio > anioActual) {
            System.out.println(
                    "El año debe estar entre 1900 y "
                    + anioActual
                    + ". Se asignara el año 1900."
            );

            this.anio = 1900;
        } else {
            this.anio = anio;
        }
    }

    /**
     * Muestra los datos generales del vehículo.
     */
    public void mostrarInformacion() {
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Año: " + anio);
    }
}
