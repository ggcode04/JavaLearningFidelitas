/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logic;

/**
 *
 * @author Gabriel Granados Ureña
 * CURSO INTRODUCCION A LA PROGRAMACIÓN
 * GRUPO 1
 * 2026
 */

import model.CitaMedica;
import model.Encargado;
import model.PacientePediatrico;
import model.ServicioMedico;

public class SistemaPediatria {
    // Para evitar cuellos de botella
    private static final int MAX_ENCARGADOS = 100;
    private static final int MAX_PACIENTES = 100;
    private static final int MAX_CITAS = 200;
    private static final int CANTIDAD_SERVICIOS = 4;
    
    // Listado de encargados, pacientes, citas y servicios
    private Encargado[] encargados;
    private int totalEncargados;
    
    private PacientePediatrico[] pacientes;
    private int totalPacientes;
    
    private CitaMedica[] citas;
    private int totalCitas;
    
    private ServicioMedico[] servicios;
    private double totalFacturado;
    
    // Constructor de Sistema Pediatria
    public SistemaPediatria (){
        encargados = new Encargado [MAX_ENCARGADOS];
        pacientes = new PacientePediatrico [MAX_PACIENTES];
        citas = new CitaMedica [MAX_CITAS];
        servicios = new ServicioMedico [CANTIDAD_SERVICIOS];
        totalEncargados = 0;
        totalPacientes = 0;
        totalCitas = 0;
        totalFacturado = 0.0;
        inicializarServicios();
    }
    
    // Metodo de inicializacion de servicios
    // Arreglo Para guardar en memoria datos como si fuera DB
    private void inicializarServicios (){
        servicios[0] = new ServicioMedico("S01", "Consulta Pediatrica", 25000);
        servicios[1] = new ServicioMedico("S02", "Vacunación", 15000);
        servicios[2] = new ServicioMedico("S03", "Control de crecimiento", 18000);
        servicios[3] = new ServicioMedico("S04", "Atencion Prioritaria", 35000);
    }
    
    // Encargados
    public String registrarEncargado(String nombreCompleto, String identificacion, String telefono, String correo){
        if (identificacion == null || identificacion.trim().isEmpty()){
            return "Error: La identificación del encargado no puede estar vacía.";
        }
        
        if (buscarEncargadoPorIdentificacion(identificacion) != null){
            return "Error: Ya existe un encargado registrado con esa identificación.";
        }
        
        if (totalEncargados >= encargados.length){
            return "Error: Se ha alcanzado el limite máximo de encargados.";
        }
        encargados[totalEncargados] = new Encargado(nombreCompleto, identificacion, telefono, correo);
        totalEncargados++;
        return "Encargado Registrado Correctamente.";
    }
    
    public Encargado buscarEncargadoPorIdentificacion(String identificacion){
        if (identificacion == null) return null;
        for (int i = 0; i < totalEncargados; i++){
            if (encargados[i].getIdentificacion().equalsIgnoreCase(identificacion.trim())){
                return encargados[i];
            }
        }
        return null;
    }
    
    public Encargado[] getEncargado(){
        return encargados;
    }
    public int getTotalEncargados(){
        return totalEncargados;
    }
    
    // Pacientes
    public String registrarPaciente(String nombreCompleto, int edad, double peso, double estatura, String padecimientoRelevante, String identificacionEncargado){
        if(nombreCompleto == null || nombreCompleto.trim().isEmpty()){
            return "Error: El nombre del paciente no puede estar vacío.";
        }
        
        if(buscarEncargadoPorIdentificacion(identificacionEncargado) == null){
            return "Error: No existe un encargado registrado con la identificación seleccionada.";
        }
        
        if (totalPacientes >= pacientes.length){
            return "Error: Se ha alcanzado el limite maximo de pacientes.";
        }
        pacientes[totalPacientes] = new PacientePediatrico(nombreCompleto, edad, peso, estatura, padecimientoRelevante, identificacionEncargado);
        totalPacientes++;
        return "Paciente Registrado Correctamente.";
    }
    
    public PacientePediatrico buscarPacientePorNombre(String nombreCompleto){
        if (nombreCompleto == null) return null;
        for (int i = 0; i < totalPacientes; i++){
            if (pacientes[i].getNombreCompleto().equalsIgnoreCase(nombreCompleto.trim())){
                return pacientes[i];
            }
        }
        return null;
    }
    
    public PacientePediatrico[] getPacientes(){
        return pacientes;
    }
    public int getTotalPacientes(){
        return totalPacientes;
    }
    
    // Servicios
    public ServicioMedico[] getServicios(){
        return servicios;
    }
    
    public ServicioMedico buscarServicioPorCodigo(String codigo){
        if (codigo == null) return null;{
            for (ServicioMedico servicio: servicios){
                if (servicio.getCodigo().equalsIgnoreCase(codigo.trim()))
                    return servicio;
            }
        }
        return null;
    }
    
    // Citas
    public String registrarCita(String nombrePaciente, String tipoServicio, String motivoCita, String fecha, double montoTotal){
        if (buscarPacientePorNombre(nombrePaciente) == null){
            return "Error: No existe un paciente registrado con ese nombre.";
        }
        ServicioMedico servicio = buscarServicioPorCodigo(tipoServicio);
        
        if (servicio == null) {
            return "Error: El servicio seleccionado no es válido";
        }
        
        if (motivoCita == null || motivoCita.trim().isEmpty()){
            return "Error: El motivo de la cita no puede estar vacío.";
        }
        
        if (fecha == null || fecha.trim().isEmpty()){
            return "Error: La fecha de atención no puede estar vacía.";
        }
        
        if (totalCitas >= citas.length){
            return "Error: Se ha alcanzado el límite máximo de citas.";
        }
        double montoTotal1 = servicio.calcularPrecioServicio();
        citas[totalCitas] = new CitaMedica(nombrePaciente, servicio.getNombreServicio(), motivoCita, fecha, montoTotal);
        totalFacturado += montoTotal1;
        totalCitas++;
        return "Cita Registrada Correctamente.";
    }
    
    public CitaMedica[] getCitas(){
        return citas;
    }
    
    public int getTotalCitas(){
        return totalCitas;
    }
    
    public double getTotalFacturado(){
        return totalFacturado;
    }
    
    // Busqueda
    public String buscarPorIdentificacionEncargado(String identificacion){
        Encargado encargado = buscarEncargadoPorIdentificacion(identificacion);
        if (encargado == null){
            return "No se encontró ningun encargado con la idenfitificación '" + identificacion + "'.";
        }
        StringBuilder resultado = new StringBuilder();
        resultado.append(encargado.mostrarInformacionEncargado()).append("\n\n");
        resultado.append("Paciente(s) a su cargo:\n");
        boolean tienePacientes = false;
        for (int i = 0; i < totalPacientes; i++){
            if (pacientes[i].getIdentificacionEncargado().equalsIgnoreCase(identificacion.trim())){
                tienePacientes = true;
                resultado.append("-").append(pacientes[i].mostrarInformacionPaciente()).append("\n");
                resultado.append("Citas: \n");
                boolean tieneCitas = false;
                for (int j = 0; j < totalCitas; j++){
                    if (citas[j].getNombrePaciente().equalsIgnoreCase(pacientes[i].getNombreCompleto())){
                        tieneCitas = true;
                        resultado.append(" *").append(citas[j].mostrarCita()).append("\n");
                    }
                }
                if (!tieneCitas){
                    resultado.append(" (sin citas registradas.)\n");
                }
            }
            if (!tienePacientes){
                resultado.append(" (sin pacientes registrados.)\n");
            }
            return resultado.toString();
        }
        return null;
    }
    
    public String buscarPorNombrePaciente(String nombreCompleto){
        PacientePediatrico paciente = buscarPacientePorNombre(nombreCompleto);
        if (paciente == null){
            return "No se encontró ningun encargado con el nombre '" + nombreCompleto + "'.";
        }
        StringBuilder resultado = new StringBuilder();
        resultado.append("Encargado encontrado:\n");
        resultado.append(paciente.mostrarInformacionPaciente()).append("\n\n");
        Encargado encargado = buscarEncargadoPorIdentificacion(paciente.getIdentificacionEncargado());
        resultado.append("Encargado:\n");
        if (encargado != null){
            resultado.append(encargado.mostrarInformacionEncargado()).append("\n");
        } else {
            resultado.append("(no se encontro informacion del encargado)\n\n");
        }
        resultado.append("Citas registradas: \n");
        boolean tieneCitas = false;
        for (int i = 0; i < totalCitas; i++){
            if (citas[i].getNombrePaciente().equalsIgnoreCase(pacientes[i].getNombreCompleto())){
                tieneCitas = true;
                resultado.append(" - ").append(citas[i].mostrarCita()).append("\n");
            }
        }
        if(!tieneCitas){
            resultado.append(" (sin citas registradas)\n");
        }
        return resultado.toString();
        
        
    }
    // Reportes
    public String generarReporte(){
        StringBuilder reporte = new StringBuilder();
        reporte.append("===REPORTE GENERAL - Clinica Pediatrica===\n\n");
        reporte.append("Total de encargados registrados: ").append(totalEncargados).append("\n");
        reporte.append("Total de pacientes registrados: ").append(totalPacientes).append("\n");
        reporte.append("Total de citas realizadas: ").append(totalCitas).append("\n");
        reporte.append("Total de dinero facturado: ").append(totalFacturado).append("\n");
        reporte.append("Servicio mas utilizado: ").append(obtenerServicioMasUtilizado()).append("\n");
        return reporte.toString();
    }
    
    private String obtenerServicioMasUtilizado(){
        if(totalCitas == 0){
            return "Sin datos (no hay citas registradas)";
            }
        int[] conteos = new int[servicios.length];
        for(int i = 0; i < totalCitas; i++){
            for(int j = 0; j < servicios.length; j++){
                if(citas[i].gettipoServicio().equalsIgnoreCase(servicios[j].getNombreServicio())){
                    conteos[j]++;
                    break;    
                }
            }
        }
        int indiceMax = 0;
        for(int j = 0; j < conteos.length; j++){
            if(conteos[j] < conteos[indiceMax]){
                indiceMax = j;
            }
        }
        if(conteos[indiceMax] == 0) return "Sin datos (no hay citas registradas)";
        return servicios[indiceMax].getNombreServicio() + " (" + conteos[indiceMax] + " citas)";
    }
}
