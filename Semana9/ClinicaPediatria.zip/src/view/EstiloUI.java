/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;
// Importar biblioteca para realizar interfaz grafica
import java.awt.Color;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

/**
 *
 * @author gabri
*/

public class EstiloUI {
    public static final Color AZUL_INSTITUCIONAL = new Color(0x28, 0x35, 0x8E);
    public static final Color AZUL_OSCURO = new Color(0x1F, 0x2A, 0x78);
    public static final Color GRIS_CLARO = new Color(0xF3, 0xF5, 0xF8);
    public static final Color BLANCO = Color.WHITE;
    
    // Definicion de Letras
    public static final Font FUENTE_TITULO = new Font("Arial", Font.BOLD, 18);
    public static final Font FUENTE_SUBTITULO = new Font("Arial", Font.BOLD, 13);
    public static final Font FUENTE_NORMAL = new Font("Arial", Font.PLAIN, 12);
    
    private EstiloUI(){}
    
    public static JLabel crearTitulo(String texto){
        JLabel etiqueta = new JLabel(texto, SwingConstants.LEFT);
        etiqueta.setOpaque(true);
        etiqueta.setBackground(AZUL_INSTITUCIONAL);
        etiqueta.setForeground(BLANCO);
        etiqueta.setFont(FUENTE_TITULO);
        etiqueta.setBorder(BorderFactory.createEmptyBorder(10,14,10,14));
        return etiqueta;
    }
    
    public static JLabel crearSubtitulo(String texto){
        JLabel etiqueta = new JLabel(texto);
        etiqueta.setForeground(AZUL_OSCURO);
        etiqueta.setFont(FUENTE_SUBTITULO);
        return etiqueta;
    }
    
    
        
    
}
