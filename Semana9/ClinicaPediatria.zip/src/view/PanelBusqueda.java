/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;
import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import logic.SistemaPediatria;

/**
 *
 * @author gabri
 */
public class PanelBusqueda extends JPanel implements ActualizablePanel{
    private final SistemaPediatria sistema;
    private final JRadioButton radioEncargado;
    private final JRadioButton radioPaciente;
    private final JTextField txtBusqueda;
    private final JTextArea areaResultado;

    public PanelBusqueda(SistemaPediatria sistema) {
        this.sistema = sistema;
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel panelSuperior = new JPanel();
        radioEncargado = new JRadioButton("Por identification del encargado"//<editor-fold defaultstate="collapsed" desc="comment">
                , true
//</editor-fold>
);
        radioPaciente = new JRadioButton("Por nombre del paciente");
        ButtonGroup grupo = new ButtonGroup();
        grupo.add(radioEncargado);
        grupo.add(radioPaciente);
        txtBusqueda = new JTextField(20);
        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.addActionListener(e -> realizarBusqueda());
        panelSuperior.add(radioEncargado);
        panelSuperior.add(radioPaciente);
        panelSuperior.add(txtBusqueda);
        panelSuperior.add(btnBuscar);
        
        JPanel panelNorte = new JPanel(new BorderLayout());
        panelNorte.add(EstiloUI.crearTitulo("Modulo de Busqueda"), BorderLayout.NORTH);
        panelNorte.add(panelSuperior,BorderLayout.SOUTH);
        add(panelNorte, BorderLayout.NORTH);
        
        areaResultado = new JTextArea();
        areaResultado.setEditable(false);
        areaResultado.setFont(new Font("Monospaced",Font.PLAIN,12));
        add(new JScrollPane(areaResultado),BorderLayout.CENTER);
        
    }
        
        private void realizarBusqueda(){
            String texto = txtBusqueda.getText().trim();
            if (texto.isEmpty()){
                JOptionPane.showMessageDialog(this, "Ingese un valor de busqueda");
                return;
            }
            if (radioEncargado.isSelected()){
                areaResultado.setText(sistema.buscarPorIdentificacionEncargado(texto));
            }else{
                areaResultado.setText(sistema.buscarPorNombrePaciente(texto));
            }           
        }
        
        @Override
        public void actualizar(){}   
}
