/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import logic.SistemaPediatria;
import model.CitaMedica;
import model.PacientePediatrico;
import model.ServicioMedico;

/**
 *
 * @author gabri
 */
public class PanelCitas extends JPanel implements ActualizablePanel{
    private final SistemaPediatria sistema;
    private final JComboBox<String> comboPacientes;
    private final JComboBox<String> comboServicios;
    private final JTextField txtMotivo;
    private final JTextField txtFecha;
    private final DefaultTableModel modeloTabla;
    private final JTable tabla;
    
    public PanelCitas(SistemaPediatria sistema){
        this.sistema = sistema;
        setLayout(new BorderLayout(10,10));
        setBorder(BorderFactory.createEmptyBorder(10,10,10,10));        
        add(EstiloUI.crearSubtitulo("Modulo de Citas"),BorderLayout.NORTH);
        
        JPanel formulario = new JPanel(new GridLayout(5,2,8,8));
        formulario.setBorder(BorderFactory.createEmptyBorder(10,0,10,0));
        
        comboPacientes = new JComboBox<>();
        comboServicios = new JComboBox<>();
        txtMotivo = new JTextField();
        txtFecha = new JTextField();
        
        txtFecha.setToolTipText("Formato sugerido: dd/mm/aaaa");
        
        formulario.add(new JLabel("Paciente:"));
        formulario.add(comboPacientes);
        formulario.add(new JLabel("Servicio:"));
        formulario.add(comboServicios);
        formulario.add(new JLabel("Motivo de la cita:"));
        formulario.add(txtMotivo);
        formulario.add(new JLabel("Fecha de atencion:"));
        formulario.add(txtFecha);
        
        
        JButton btnRegistrar = new JButton("Registrar cita");
        btnRegistrar.addActionListener(e -> registrarCita());
        formulario.add(new JLabel());
        formulario.add(btnRegistrar);
        add(formulario, BorderLayout.SOUTH);
               
        modeloTabla = new DefaultTableModel(new Object[]{"Paciente", "Servicio", "Motico","Fecha","Precio total"},0){
            @Override
            public boolean isCellEditable(int row, int column){
                return false;           
            }        
        };
        tabla = new JTable(modeloTabla);
        add(new JScrollPane(tabla), BorderLayout.CENTER);
        //actualizar();
    }
    
    public void registrarCita(){
        if (comboPacientes.getSelectedItem()== null){
            JOptionPane.showMessageDialog(this, "Error: primero debe registrar al menos un paciente");
            return;
        }
        String nombrePaciente = (String) comboPacientes.getSelectedItem();
        String itemServicio = (String) comboServicios.getSelectedItem();
        String codigoServicio = itemServicio.split(" - ")[0];
        String resultado = sistema.registrarCita(nombrePaciente, codigoServicio, txtMotivo.getText().trim(), txtFecha.getText().trim(), 0);
        JOptionPane.showMessageDialog(this, resultado);
        if (resultado.startsWith("Cita registrada")){
            txtMotivo.setText("");
            txtFecha.setText("");
            actualizar();
        }
    }
    
    @Override
    public void actualizar(){
        String seleccionado = (String) comboPacientes.getSelectedItem();
        comboPacientes.removeAllItems();
        PacientePediatrico[] pacientes = sistema.getPacientes();
        for (int i=0; i<sistema.getTotalPacientes(); i++){
            comboPacientes.addItem(pacientes[i].getNombreCompleto());
        }
        if(seleccionado != null) comboPacientes.setSelectedItem(seleccionado);
        
        if(comboServicios.getItemCount()==0){
            for (ServicioMedico s : sistema.getServicios()){
                comboServicios.addItem(s.getCodigo() + " - " + s.getNombreServicio() + " (Total :" + s.calcularPrecioServicio() + ")");
            }
        }
               
        
        modeloTabla.setRowCount(0);
        CitaMedica[] citas = sistema.getCitas();
        for(int i =0; i<sistema.getTotalCitas();i++){
            modeloTabla.addRow(new Object[]{citas[i].getNombrePaciente(), citas[i].getTipoServicio(),citas[i].getMotivoCita(),citas[i].getFecha(), citas[i].getMontoTotal()});   
        }
    }  
}
