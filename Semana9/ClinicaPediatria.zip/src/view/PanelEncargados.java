/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;
// Importar biblioteca para realizar interfaz grafica
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import logic.SistemaPediatria;
import model.Encargado;

/**
 *
 * @author gabri
*/

public class PanelEncargados extends JPanel implements ActualizablePanel{
    private final SistemaPediatria sistema;
    private final JTextField txtNombre;
    private final JTextField txtIdentificacion;
    private final JTextField txtTelefono;
    private final JTextField txtCorreo;
    private final DefaultTableModel modeloTabla;
    private final JTable tabla;
    
    public PanelEncargados(SistemaPediatria sistema){
        this.sistema = sistema;
        setLayout(new BorderLayout(10,10));
        setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        
        add(EstiloUI.crearSubtitulo("Modulo de Encargados"), BorderLayout.NORTH);
        
        JPanel formulario = new JPanel(new GridLayout(5,2,8,8));
        formulario.setBorder(BorderFactory.createEmptyBorder(10,0,10,0));
        
        txtNombre = new JTextField();
        txtIdentificacion = new JTextField();
        txtTelefono = new JTextField();
        txtCorreo = new JTextField();
        
        formulario.add(new JLabel("Nombre Completo: "));
        formulario.add(txtNombre);
        formulario.add(new JLabel("Identificacion: "));
        formulario.add(txtIdentificacion);
        formulario.add(new JLabel("Telefono: "));
        formulario.add(txtTelefono);
        formulario.add(new JLabel("Correo Electronico: "));
        formulario.add(txtCorreo);
        
        JButton btnRegistrar = new JButton("Registrar encargado");
        btnRegistrar.addActionListener(e -> registrarEncargado());
        formulario.add(new JLabel());
        formulario.add(btnRegistrar);
        
        add(formulario, BorderLayout.SOUTH);
        
        modeloTabla = new DefaultTableModel(new Object[]{"Identificacion","Nombre","Telefono","Correo"},0){
            @Override
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        tabla = new JTable(modeloTabla);
        add(new JScrollPane(tabla), BorderLayout.CENTER);
    }
    
    private void registrarEncargado(){
        String resultado = sistema.registrarEncargado(txtNombre.getText().trim(), txtIdentificacion.getText().trim(), txtTelefono.getText().trim(), txtCorreo.getText().trim());
        JOptionPane.showMessageDialog(this, resultado);
        if (resultado.startsWith("Encargado registrado")){
            txtNombre.setText("");
            txtIdentificacion.setText("");
            txtTelefono.setText("");
            txtCorreo.setText("");
            actualizar();
        }
    }
    
    @Override
    public void actualizar(){
        modeloTabla.setRowCount(0);
        Encargado[] encargados = sistema.getEncargado();
        for(int i = 0; i < sistema.getTotalEncargados(); i++){
            modeloTabla.addRow(new Object[]{
                encargados[i].getIdentificacion(),
                encargados[i].getNombreCompleto(),
                encargados[i].getTelefono(),
                encargados[i].getCorreo()
            });
        }
    }
}
