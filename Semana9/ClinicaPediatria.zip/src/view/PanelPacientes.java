/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;
// Importar biblioteca para realizar interfaz grafica
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import logic.SistemaPediatria;
import model.PacientePediatrico;

/**
 *
 * @author gabri
 */
public class PanelPacientes extends JPanel implements ActualizablePanel{
    private final SistemaPediatria sistema;
    private final JTextField txtNombre;
    private final JTextField txtEdad;
    private final JTextField txtPeso;
    private final JTextField txtEstatura;
    private final JTextField txtPadecimiento;
    private final JTextField txtIdEncargado;
    private final DefaultTableModel modeloTabla;
    private final JTable tabla;
    
    public PanelPacientes(SistemaPediatria sistema){
        this.sistema = sistema;
        setLayout(new BorderLayout(10,10));
        setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        
        add(EstiloUI.crearSubtitulo("Modulo de Pacientes"), BorderLayout.NORTH);
        
        JPanel formulario = new JPanel(new GridLayout(7,2,8,8));
        formulario.setBorder(BorderFactory.createEmptyBorder(10,0,10,0));
        
        txtNombre = new JTextField();
        txtEdad = new JTextField();
        txtPeso = new JTextField();
        txtEstatura = new JTextField();
        txtPadecimiento = new JTextField();
        txtIdEncargado = new JTextField();
        
        formulario.add(new JLabel("Nombre Completo: "));
        formulario.add(txtNombre);
        formulario.add(new JLabel("Edad (anios): "));
        formulario.add(txtEdad);
        formulario.add(new JLabel("Peso (kg): "));
        formulario.add(txtPeso);
        formulario.add(new JLabel("Estatura (cm): "));
        formulario.add(txtEstatura);
        formulario.add(new JLabel("Padecimiento relevante: "));
        formulario.add(txtPadecimiento);
        formulario.add(new JLabel("ID Encargado: "));
        formulario.add(txtIdEncargado);
        
        JButton btnRegistrar = new JButton("Registrar Paciente");
        btnRegistrar.addActionListener(e -> registrarPaciente());
        formulario.add(new JLabel());
        formulario.add(btnRegistrar);
        
        add(formulario, BorderLayout.SOUTH);
        
        modeloTabla = new DefaultTableModel(new Object[]{"Nombre", "Edad", "Peso", "Estatura", "Padecimiento", "IdEncargado"},0){
            @Override
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        tabla = new JTable(modeloTabla);
        add(new JScrollPane(tabla), BorderLayout.CENTER);
    }

    private void registrarPaciente(){
        int edad;
        double peso;
        double estatura;
        try {
            edad = Integer.parseInt(txtEdad.getText().trim());
            peso = Integer.parseInt(txtPeso.getText().trim());
            estatura = Integer.parseInt(txtEstatura.getText().trim());
        }
        catch(NumberFormatException ex){
            JOptionPane.showMessageDialog(this, "Error: edad, peso y estatura deben ser valores numericos.");
            return;
        }
        
        String resultado = sistema.registrarPaciente(txtNombre.getText().trim(), edad, peso, estatura, txtPadecimiento.getText().trim(), txtIdEncargado.getText().trim());
        JOptionPane.showMessageDialog(this, resultado);
        if (resultado.startsWith("Paciente registrado")){
            txtNombre.setText("");
            txtEdad.setText("");
            txtPeso.setText("");
            txtEstatura.setText("");
            txtPadecimiento.setText("");
            txtIdEncargado.setText("");
            actualizar();
        }
    }

    @Override
    public void actualizar(){
        modeloTabla.setRowCount(0);
        PacientePediatrico[] pacientes = sistema.getPacientes();
        for(int i = 0; i < sistema.getTotalPacientes(); i++){
            modeloTabla.addRow(new Object[]{
                pacientes[i].getNombreCompleto(),
                pacientes[i].getEdad(),
                pacientes[i].getPeso(),
                pacientes[i].getEstatura(),
                pacientes[i].getPadecimientoRelevante(),
                pacientes[i].getIdentificacionEncargado()
            });
        }
    }
}
