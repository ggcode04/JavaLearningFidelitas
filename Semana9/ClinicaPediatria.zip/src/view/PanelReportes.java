/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;
import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import logic.SistemaPediatria;

/**
 *
 * @author gabri
 */
public class PanelReportes extends JPanel implements ActualizablePanel{
    private final SistemaPediatria sistema;
    private final JTextArea areaReporte;

    public PanelReportes(SistemaPediatria sistema) {
        this.sistema = sistema;
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel panelNorte = new JPanel(new BorderLayout());
        panelNorte.add(EstiloUI.crearTitulo("Modulo de Reportes"), BorderLayout.NORTH);
        JButton btnGenerar = new JButton("Generar reporte");
        btnGenerar.addActionListener(e -> actualizar());
        JPanel panelBoton = new JPanel();
        
        panelBoton.add(btnGenerar);
        panelNorte.add(panelBoton, BorderLayout.SOUTH);
        add(panelNorte, BorderLayout.NORTH);

        areaReporte = new JTextArea();
        areaReporte.setEditable(false);
        areaReporte.setFont(new Font("Monospaced",Font.PLAIN,13));
        add(new JScrollPane(areaReporte),BorderLayout.CENTER);
    }
    
    @Override
    public void actualizar(){
        areaReporte.setText(sistema.generarReporte());
    }   
}

