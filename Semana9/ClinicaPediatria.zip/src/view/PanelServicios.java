/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;
// Importar biblioteca para realizar interfaz grafica
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import logic.SistemaPediatria;
import model.ServicioMedico;

/**
 *
 * @author gabri
*/

public class PanelServicios extends JPanel implements ActualizablePanel{
    private final SistemaPediatria sistema;
    private final DefaultTableModel modeloTabla;
    private final JTable tabla;
    
    public PanelServicios(SistemaPediatria sistema){
        this.sistema = sistema;
        setLayout(new BorderLayout(10,10));
        setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        
        add(EstiloUI.crearSubtitulo("Modulo de Servicios"), BorderLayout.NORTH);
        
        modeloTabla = new DefaultTableModel(new Object[]{"Codigo", "Servicios", "Precio Base", "IVA", "Precio Total"},0){
            @Override
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        tabla = new JTable(modeloTabla);
        add(new JScrollPane(tabla), BorderLayout.CENTER);
    }

    @Override
    public void actualizar(){
        modeloTabla.setRowCount(0);
        for(ServicioMedico s: sistema.getServicios()){
            modeloTabla.addRow(new Object[]{
                s.getCodigo(),
                s.getNombreServicio(),
                s.getPrecioBase(),
                s.calcularIVA(),
                s.calcularPrecioServicio(),
            });
        }
    }
}
