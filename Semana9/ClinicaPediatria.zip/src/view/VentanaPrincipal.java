/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;
import logic.SistemaPediatria;

/**
 *
 * @author gabri
 */
public class VentanaPrincipal extends JFrame{
    private final SistemaPediatria sistema;
    private final JTabbedPane pestanas;
    
    public VentanaPrincipal(){
        super("Sistema de Gestion - Clinica Pedriatrica Crecer");
        sistema = new SistemaPediatria();
        
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter(){
            @Override
            public void windowClosing(WindowEvent e){
                confirmarSalida();
            }
        });
        
        setLayout(new BorderLayout());
        add(crearEncabezado(), BorderLayout.NORTH);
        
        pestanas = new JTabbedPane();
        
        PanelEncargados panelEncargados = new PanelEncargados(sistema);
        PanelPacientes panelPacientes = new PanelPacientes(sistema);
        PanelServicios panelServicios = new PanelServicios(sistema);
        PanelCitas panelCitas= new PanelCitas(sistema);
        PanelBusqueda panelBusqueda = new PanelBusqueda(sistema);
        PanelReportes panelReportes = new PanelReportes(sistema);
        
        pestanas.addTab("Encargados", panelEncargados);
        pestanas.addTab("Pacientes", panelPacientes);
        pestanas.addTab("Servicios", panelServicios);
        pestanas.addTab("Citas", panelCitas);
        pestanas.addTab("Busqueda", panelBusqueda);
        pestanas.addTab("Reportes", panelReportes);
        pestanas.addTab("Salir", crearPanelSalida());
        
        pestanas.addChangeListener(e -> {
            Component seleccionado = pestanas.getSelectedComponent();
            if(seleccionado instanceof ActualizablePanel){
                ((ActualizablePanel) seleccionado).actualizar();
            }
        });
        
        panelEncargados.actualizar();
        panelPacientes.actualizar();
        panelServicios.actualizar();
        panelCitas.actualizar();
        panelReportes.actualizar();
        
        add(pestanas, BorderLayout.CENTER);
        setSize(950,600);
        setLocationRelativeTo(null);
    }
    
    private JPanel crearEncabezado(){
        JPanel encabezado = new JPanel(new BorderLayout());
        encabezado.setBackground(EstiloUI.AZUL_OSCURO);
        encabezado.setBorder(BorderFactory.createEmptyBorder(8,14,8,14));
        
        JLabel titulo = new JLabel("Clinica Pediatrica \"Crecer \"", SwingConstants.LEFT);
        titulo.setForeground(EstiloUI.BLANCO);
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        
        JLabel subtitulo = new JLabel("Sistema de gestion - SC-202 Introduccion a la programacion", SwingConstants.LEFT);
        titulo.setForeground(EstiloUI.BLANCO);
        titulo.setFont(new Font("Arial", Font.BOLD, 12));
        
        JPanel textos = new JPanel(new BorderLayout());
        textos.setOpaque(false);
        textos.add(titulo, BorderLayout.NORTH);
        textos.add(subtitulo, BorderLayout.SOUTH);
        encabezado.add(textos, BorderLayout.WEST);
        return encabezado;       
    }
    
    private JPanel crearPanelSalida(){
        JPanel panel = new JPanel(new BorderLayout(10,10));
        panel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        panel.add(EstiloUI.crearTitulo("Salir del sitema"), BorderLayout.NORTH);
        
        JLabel mensaje = new JLabel(
                "<html><br>Presione el boton para salir del sistema.<br>" +
                "Se le pedira confirmacion antes de cerrar la aplicacion.</html>", SwingConstants.CENTER);
        
        mensaje.setFont(EstiloUI.FUENTE_NORMAL);
        
        JButton btnSalir = new JButton("Salir del sistema");
        btnSalir.addActionListener(e -> confirmarSalida());
        
        JPanel centro = new JPanel(new BorderLayout(10,10));
        centro.add(mensaje, BorderLayout.CENTER);
        JPanel panelBoton = new JPanel();
        panelBoton.add(btnSalir);
        centro.add(panelBoton, BorderLayout.SOUTH);
        
        panel.add(centro, BorderLayout.CENTER);
        return panel;   
    }
    
    private void confirmarSalida(){
        int opcion = JOptionPane.showConfirmDialog(this, "Desea salir del sistema de Gestion de la Clinica Pediatrica?", "Desea confirmar salida", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (opcion == JOptionPane.YES_OPTION){
            dispose();
            System.exit(0);
        }
    
    }
    
    
    
}
